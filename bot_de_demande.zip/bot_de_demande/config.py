data = {
"token": "1892620363:AAHiAFOeemFUNtz3TwTY4xuz07UDWzt2Q2g",
"text": "Veuillez déposer votre invitation, dites nous, quel est votre expérience en arnaque et combien de bénéfice avez-vous déjà fait ?!"
}